from django.contrib import admin
from .models import StlFile
# Register your models here.

admin.site.register(StlFile)

