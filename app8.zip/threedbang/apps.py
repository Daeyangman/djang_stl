from django.apps import AppConfig


class ThreedbangConfig(AppConfig):
    name = 'threedbang'
